import React, { useState } from 'react';

const Logincomp = () => {
  const [checked, setChecked] = useState(false);

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  return (
    <div className='h- w-[130vh] mr-0 ml-64 shadow-xl m-10 border-gray-200 border-[0.5px] shadow-gray-300'>
      <div className="p-16">
        <h1 className='font-semibold text-2xl pl-64'>Login</h1><br />
        <p className='pl-44'>Enter Login details to get access</p>
      </div>

      <div className="pl-11 mb-5">
        <h3 className='font-semibold'>Username or Email Address</h3>
        <input
          className="placeholder:text-slate-400 block h-14 bg-white w-[110vh] border border-slate-300 py-2 pl-5 pr-3 mt-2 shadow-sm sm:text-sm focus:outline-none"
          placeholder="Username / Email Address"
          type="text"
          name="search"
        />
      </div>

      <div className="pl-11">
        <h3 className='font-semibold'>Password</h3>
        <input
          className="placeholder:text-slate-400 block h-14 bg-white w-[110vh] border border-slate-300 py-2 pl-5 pr-3 mt-2 shadow-sm sm:text-sm focus:outline-none"
          placeholder="Enter Password"
          type="password"
        />
      </div>

      <div className="pl-11 mt-8 mb-24 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={checked}
            onChange={handleChange}
            className="form-checkbox h-5 w-5 border-gray-200 rounded"
          />
          <label className="text-gray-700 font-semibold">Keep Me Logged In</label>
        </div>
        <p className='text-[#ff2020] cursor-pointer pr-16'>Forget Password?</p>
      </div>

      <div className="pl-11 mt-8 mb-20 flex items-center justify-between">
        <p>Don’t have an account?<span className='text-[#ff2020]'><a href="#"> Sign Up </a></span>here</p>
        <button className='bg-[#ff2020] text-white h-10 px-8 mr-16'>Login</button>
      </div>
    </div>
  );
};

export default Logincomp;
