import React, { useState } from "react";
import { Menu, Transition } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import "./Navbar.css";
import fb from "../../assets/facebook.svg";
import linkin from "../../assets/linkin.png";
import inst from "../../assets/video.png";
import twit from "../../assets/twitter.png";
import utube from "../../assets/play.png";
import navpic from "../../assets/navpic.webp";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <>
      <header className="bg-white border-b border-gray-300 shadow-lg">
        <div className="justify-between items-center py-2 px-[5%] hidden sm:flex">
          <div className="navelements flex gap-5">
            <div className="aboutus">About</div>
            <div className="privacy">Privacy</div>
            <div className="faqs">FAQ</div>
            <div className="careers">Careers</div>
          </div>
          <div className="flex gap-5 items-center">
            <div className="rightdiv flex gap-5 items-center pr-10">
              <div className="mywishlist">My wishlist</div>
              <div className="border-[0.5px] border-gray-300 h-6"></div>
              <div className="track">Track Your Orders</div>
            </div>
          </div>
          <div className="icons flex h-5 gap-4 cursor-pointer">
            <span>
              <img className="facebook h-full" src={fb} alt="Facebook" />
            </span>
            <span>
              <img className="instagram h-full" src={inst} alt="Instagram" />
            </span>
            <span>
              <img className="twitter h-full" src={twit} alt="Twitter" />
            </span>
            <span>
              <img className="linkin h-full" src={linkin} alt="LinkedIn" />
            </span>
            <span>
              <img className="youtube h-full" src={utube} alt="YouTube" />
            </span>
          </div>
        </div>
      </header>

      <main className="sticky top-0 bg-white z-50 shadow-md">
        <div className="relative flex items-center justify-between p-4 h-20 bg-white shadow-md">
          <div className="flex items-center">
            <img src={navpic} alt="Navbar Pic" className="w-18 h-10" />
            <div className="hidden lg:flex lg:gap-x-10 lg:ml-8">
              <a href="/" className="font-bold">
                Home
              </a>
              <a href="/men" className="font-bold">
                Men
              </a>
              <a href="/women" className="font-bold">
                Women
              </a>
              <a href="/baby-collection" className="font-bold">
                Baby Collection
              </a>
              <Menu as="div" className="relative inline-block text-left">
                <Menu.Button className="inline-flex w-full justify-center gap-x-1.5 rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900">
                  Pages
                  <ChevronDownIcon
                    aria-hidden="true"
                    className="-mr-1 h-5 w-5 text-black-400"
                  />
                </Menu.Button>
                <Menu.Items className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="py-1">
                    <Menu.Item>
                      {({ active }) => (
                        <a
                          href="/login"
                          className={`block px-4 py-2 text-sm text-gray-700 ${
                            active ? "bg-gray-100 text-gray-900" : ""
                          }`}
                        >
                          Login
                        </a>
                      )}
                    </Menu.Item>
                    <Menu.Item>
                      {({ active }) => (
                        <a
                          href="/cart"
                          className={`block px-4 py-2 text-sm text-gray-700 ${
                            active ? "bg-gray-100 text-gray-900" : ""
                          }`}
                        >
                          Cart
                        </a>
                      )}
                    </Menu.Item>
                    <Menu.Item>
                      {({ active }) => (
                        <a
                          href="/product"
                          className={`block px-4 py-2 text-sm text-gray-700 ${
                            active ? "bg-gray-100 text-gray-900" : ""
                          }`}
                        >
                          Product Details
                        </a>
                      )}
                    </Menu.Item>
                    <Menu.Item>
                      {({ active }) => (
                        <a
                          href="/product-cart"
                          className={`block px-4 py-2 text-sm text-gray-700 ${
                            active ? "bg-gray-100 text-gray-900" : ""
                          }`}
                        >
                          Product Cart
                        </a>
                      )}
                    </Menu.Item>
                  </div>
                </Menu.Items>
              </Menu>
              <a href="/blog" className="font-bold">
                Blog
              </a>
              <a href="/contact" className="font-bold">
                Contact
              </a>
            </div>
          </div>

          <button className="lg:hidden p-2" onClick={toggleMenu}>
            <svg
              className="w-6 h-6 text-gray-700"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 6h16M4 12h16m-7 6h7"
              ></path>
            </svg>
          </button>

          {/* Mobile Menu */}
          <div
            className={`fixed inset-x-0 top-0 z-50 bg-white shadow-lg transform ${
              isOpen ? "translate-y-0" : "-translate-y-full"
            } transition-transform duration-300 lg:hidden`}
            style={{ height: "calc(100vh - 4rem)" }}
          >
            <div className="flex justify-between items-center p-4 border-b">
              <img src={navpic} alt="Navbar Pic" className="w-18 h-10" />
              <button onClick={toggleMenu} className="text-gray-700">
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  ></path>
                </svg>
              </button>
            </div>
            <div className="flex flex-col items-center p-4">
              <a href="/" className="py-2 text-lg font-bold">
                Home
              </a>
              <a href="/men" className="py-2 text-lg font-bold">
                Men
              </a>
              <a href="/women" className="py-2 text-lg font-bold">
                Women
              </a>
              <a href="/baby-collection" className="py-2 text-lg font-bold">
                Baby Collection
              </a>
              <Menu as="div" className="relative">
                <Menu.Button className="w-full py-2 text-lg font-bold text-left">
                  Pages
                </Menu.Button>
                <Menu.Items className="flex flex-col w-full bg-white shadow-lg">
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="/login"
                        className={`block px-4 py-2 text-sm text-gray-700 ${
                          active ? "bg-gray-100 text-gray-900" : ""
                        }`}
                      >
                        Login
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="/cart"
                        className={`block px-4 py-2 text-sm text-gray-700 ${
                          active ? "bg-gray-100 text-gray-900" : ""
                        }`}
                      >
                        Cart
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="/product"
                        className={`block px-4 py-2 text-sm text-gray-700 ${
                          active ? "bg-gray-100 text-gray-900" : ""
                        }`}
                      >
                        Product Details
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="/product-cart"
                        className={`block px-4 py-2 text-sm text-gray-700 ${
                          active ? "bg-gray-100 text-gray-900" : ""
                        }`}
                      >
                        Product Cart
                      </a>
                    )}
                  </Menu.Item>
                </Menu.Items>
              </Menu>
              <a href="/blog" className="py-2 text-lg font-bold">
                Blog
              </a>
              <a href="/contact" className="py-2 text-lg font-bold">
                Contact
              </a>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default Navbar;
