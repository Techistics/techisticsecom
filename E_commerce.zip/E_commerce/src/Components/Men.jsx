import React from 'react'
import MenC from './Men/MenC'

const Men = () => {
  return (
    <MenC/>
    
  )
}

export default Men