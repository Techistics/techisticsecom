import React from 'react'
import WomenC from './Women/WomenC'

const Women = () => {
  return (
    <WomenC/>
  )
}

export default Women