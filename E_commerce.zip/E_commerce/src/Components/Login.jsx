import React from 'react'
import Logincomp from './Login/Logincomp'

const Login = () => {
  return (
    <Logincomp/>  
  )
}

export default Login