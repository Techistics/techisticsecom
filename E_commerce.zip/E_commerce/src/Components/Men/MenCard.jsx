// import React from 'react'
// import putcream from '../../assets/putcream.webp'

// const MenCard = () => {
//   return (
//     <div className='box border-[#EDEFF2] text-sm border pt-10 gap-10 pr-20 mt-16 pl-10   border-none'>
//       <div className="r1 flex w-full gap-10">
//         <div className="p1">
//           <img src={putcream} />
//           <p className=" flex flex-col items-center mt-5 text-base">
//             Cashmere Tank + Bag
//             <span className="mt-1 font-medium text-[#74706B] text-lg">
//               $98.00 <span className="text-[#CEBD9C] mt-1 line-through pl-3 font-semibold">$120.00</span>
//             </span>
//           </p>
//         </div>

//         <div className="p1">
//           <img src={putcream} />
//           <p className=" flex flex-col items-center mt-5 text-base">
//             Cashmere Tank + Bag
//             <span className="mt-1 font-medium text-[#74706B] text-lg">
//               $98.00 <span className="text-[#CEBD9C] mt-1 line-through pl-3 font-semibold">$120.00</span>
//             </span>
//           </p>
//         </div>

//         <div className="p1">
//           <img src={putcream} />
//           <p className=" flex flex-col items-center mt-5 text-base">
//             Cashmere Tank + Bag
//             <span className="mt-1 font-medium text-[#74706B] text-lg">
//               $98.00 <span className="text-[#CEBD9C] mt-1 line-through pl-3 font-semibold">$120.00</span>
//             </span>
//           </p>
//         </div>
//       </div>

//     </div>
//   )
// }

// export default MenCard