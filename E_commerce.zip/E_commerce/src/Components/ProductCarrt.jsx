import React from 'react'
import ProductCart from './ProductCart/ProductCart'

const ProductCarrt = () => {
  return (
    <ProductCart/>
  )
}

export default ProductCarrt