import React from 'react'
import Product from './ProductDetails/Product'

const ProductDetails = () => {
  return (
    <Product/>
  )
}

export default ProductDetails